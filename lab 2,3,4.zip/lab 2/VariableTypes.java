	public class VariableTypes {
	    public static void main(String[] args) {
	     //Question 1
        String name = "John";
        int age = 25;
        double salary = 50000.50;
        char gender = 'M';
        boolean isStudent = true;

        System.out.println("Person Information:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Salary: $" + salary);
        System.out.println("Gender: " + gender);
        System.out.println("Is a student: " + isStudent);
    }
}
